This is repository for those devs who want to release kernel for j2lte.. Just replace your zImage with your's and type "export v=<your_kernel_version>" without quotes and hit enter..
Then just run build script by typing "./build" in your terminal and hit enter.. And you will get a flashable zip, flash that and enjoy!!
